import asyncio
import os
from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI
from openai import AzureOpenAI
from mcp_use import MCPAgent, MCPClient


system_prompt = """
You are a helpful assistant which can interact with ServiceNow to manage incidents.
"""


async def main():
    """Run the example using a configuration file."""
    # Load environment variables
    load_dotenv()
    config = {
    "mcpServers": {
        "ServiceNow": {
            "command": r"D:/MCP/servicenowmcp/venv/Scripts/python.exe",  # Windows venv Python
            "args": ["-m", "servicenow_mcp.cli"],
            "env": {
                "SERVICENOW_INSTANCE_URL": "https://dev309760.service-now.com",
                "SERVICENOW_USERNAME": "admin",
                "SERVICENOW_PASSWORD": "NqkkbS1F/P8=",
                "SERVICENOW_AUTH_TYPE": "basic",
            },
        }
    }
}

    # Create MCPClient from config file
    client = MCPClient.from_dict(config)

    # Create LLM
    llm = AzureChatOpenAI(
        azure_deployment="o4-mini",  # or your deployment
        api_key="A1cNbY5p1Glum6Aooyq166JbiBkGpZACr1WobXyS6G832M486BFsJQQJ99BIACHYHv6XJ3w3AAAAACOGdQH6",
        api_version="2025-01-01-preview",  # or your api version
        azure_endpoint="https://saoni-mf6zs3bd-eastus2.cognitiveservices.azure.com/",

        # max_tokens=None,
        # timeout=None,
        # max_retries=2,
        # streaming=True,
        # other params...
    )

    # # Get all tools from MCP
    # tools = client.tools  
    # print(tools)

    # Bind tools to the LLM
    # llm_with_tools = llm.bind_tools(tools)


    agent = MCPAgent(
        llm=llm,   # use llm_with_tools, not raw llm
        client=client,
        max_steps=30,
        system_prompt=system_prompt,
        verbose=True,
    )

    # Run the query
    result = await agent.run(
        "Create an incident in servicenow called 'test-client-1'",
        max_steps=30,
    )

    print(f"\nResult: {result}")



    # Create MCPClient from config file
    client = MCPClient.from_dict(config)

    # Create LLM
    # llm = AzureChatOpenAI(
    #     azure_deployment="gpt-4o",
    #     api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    #     api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    #     azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    #     temperature=0,
    #     streaming=True,
    # )


if __name__ == "__main__":
    # Run the appropriate example
    asyncio.run(main())
